(function(window, undefined) {

  var jimLinks = {
    "d897edba-97e4-46fc-ae38-a7850df3bf9f" : {
      "Two-line-item_22" : [
        "e6b4de06-9473-416c-a777-33c14c84caf5"
      ],
      "Two-line-item_34" : [
        "3ce1d6ba-3660-41a1-8ed5-d8cfe6aa4186"
      ],
      "Two-line-item_12" : [
        "e5c4986d-5cfc-4172-b800-0daeda45b832"
      ],
      "Two-line-item_23" : [
        "7d81144a-bd8e-4a84-83f1-94a7acfef088"
      ],
      "Two-line-item_28" : [
        "5a16e1a6-7f21-441e-9071-97f456c53522"
      ],
      "Two-line-item_43" : [
        "a2d965d2-311c-4174-9f0f-9777417eb4ca"
      ],
      "Two-line-item_44" : [
        "059e1423-70e2-4ca3-8ff7-9b4555e68623"
      ],
      "Two-line-item_45" : [
        "d897edba-97e4-46fc-ae38-a7850df3bf9f"
      ],
      "Button_1" : [
        "ef17f5e1-fc88-4262-91de-9a35e7112727"
      ]
    },
    "e6b4de06-9473-416c-a777-33c14c84caf5" : {
      "Two-line-item_22" : [
        "e6b4de06-9473-416c-a777-33c14c84caf5"
      ],
      "Two-line-item_34" : [
        "3ce1d6ba-3660-41a1-8ed5-d8cfe6aa4186"
      ],
      "Two-line-item_12" : [
        "e5c4986d-5cfc-4172-b800-0daeda45b832"
      ],
      "Two-line-item_23" : [
        "7d81144a-bd8e-4a84-83f1-94a7acfef088"
      ],
      "Two-line-item_28" : [
        "5a16e1a6-7f21-441e-9071-97f456c53522"
      ],
      "Two-line-item_43" : [
        "a2d965d2-311c-4174-9f0f-9777417eb4ca"
      ],
      "Two-line-item_44" : [
        "059e1423-70e2-4ca3-8ff7-9b4555e68623"
      ],
      "Two-line-item_45" : [
        "d897edba-97e4-46fc-ae38-a7850df3bf9f"
      ]
    },
    "5a16e1a6-7f21-441e-9071-97f456c53522" : {
      "Two-line-item_22" : [
        "e6b4de06-9473-416c-a777-33c14c84caf5"
      ],
      "Two-line-item_34" : [
        "3ce1d6ba-3660-41a1-8ed5-d8cfe6aa4186"
      ],
      "Two-line-item_12" : [
        "e5c4986d-5cfc-4172-b800-0daeda45b832"
      ],
      "Two-line-item_23" : [
        "7d81144a-bd8e-4a84-83f1-94a7acfef088"
      ],
      "Two-line-item_28" : [
        "5a16e1a6-7f21-441e-9071-97f456c53522"
      ],
      "Two-line-item_43" : [
        "a2d965d2-311c-4174-9f0f-9777417eb4ca"
      ],
      "Two-line-item_44" : [
        "059e1423-70e2-4ca3-8ff7-9b4555e68623"
      ],
      "Two-line-item_45" : [
        "d897edba-97e4-46fc-ae38-a7850df3bf9f"
      ]
    },
    "3ce1d6ba-3660-41a1-8ed5-d8cfe6aa4186" : {
      "Two-line-item_22" : [
        "e6b4de06-9473-416c-a777-33c14c84caf5"
      ],
      "Two-line-item_34" : [
        "3ce1d6ba-3660-41a1-8ed5-d8cfe6aa4186"
      ],
      "Two-line-item_12" : [
        "e5c4986d-5cfc-4172-b800-0daeda45b832"
      ],
      "Two-line-item_23" : [
        "7d81144a-bd8e-4a84-83f1-94a7acfef088"
      ],
      "Two-line-item_28" : [
        "5a16e1a6-7f21-441e-9071-97f456c53522"
      ],
      "Two-line-item_43" : [
        "a2d965d2-311c-4174-9f0f-9777417eb4ca"
      ],
      "Two-line-item_44" : [
        "059e1423-70e2-4ca3-8ff7-9b4555e68623"
      ],
      "Two-line-item_45" : [
        "d897edba-97e4-46fc-ae38-a7850df3bf9f"
      ]
    },
    "e5c4986d-5cfc-4172-b800-0daeda45b832" : {
      "Two-line-item_22" : [
        "e6b4de06-9473-416c-a777-33c14c84caf5"
      ],
      "Two-line-item_34" : [
        "3ce1d6ba-3660-41a1-8ed5-d8cfe6aa4186"
      ],
      "Two-line-item_12" : [
        "e5c4986d-5cfc-4172-b800-0daeda45b832"
      ],
      "Two-line-item_23" : [
        "7d81144a-bd8e-4a84-83f1-94a7acfef088"
      ],
      "Two-line-item_28" : [
        "5a16e1a6-7f21-441e-9071-97f456c53522"
      ],
      "Two-line-item_43" : [
        "a2d965d2-311c-4174-9f0f-9777417eb4ca"
      ],
      "Two-line-item_44" : [
        "059e1423-70e2-4ca3-8ff7-9b4555e68623"
      ],
      "Two-line-item_45" : [
        "d897edba-97e4-46fc-ae38-a7850df3bf9f"
      ],
      "Two-line-item_4" : [
        "a2d965d2-311c-4174-9f0f-9777417eb4ca"
      ],
      "Two-line-item_3" : [
        "a2d965d2-311c-4174-9f0f-9777417eb4ca"
      ],
      "Two-line-item_2" : [
        "a2d965d2-311c-4174-9f0f-9777417eb4ca"
      ],
      "Two-line-item_1" : [
        "a2d965d2-311c-4174-9f0f-9777417eb4ca"
      ],
      "Two-line-item" : [
        "a2d965d2-311c-4174-9f0f-9777417eb4ca"
      ]
    },
    "a2d965d2-311c-4174-9f0f-9777417eb4ca" : {
      "Two-line-item_22" : [
        "e6b4de06-9473-416c-a777-33c14c84caf5"
      ],
      "Two-line-item_34" : [
        "3ce1d6ba-3660-41a1-8ed5-d8cfe6aa4186"
      ],
      "Two-line-item_12" : [
        "e5c4986d-5cfc-4172-b800-0daeda45b832"
      ],
      "Two-line-item_23" : [
        "7d81144a-bd8e-4a84-83f1-94a7acfef088"
      ],
      "Two-line-item_28" : [
        "5a16e1a6-7f21-441e-9071-97f456c53522"
      ],
      "Two-line-item_43" : [
        "a2d965d2-311c-4174-9f0f-9777417eb4ca"
      ],
      "Two-line-item_44" : [
        "059e1423-70e2-4ca3-8ff7-9b4555e68623"
      ],
      "Two-line-item_45" : [
        "d897edba-97e4-46fc-ae38-a7850df3bf9f"
      ]
    },
    "ef17f5e1-fc88-4262-91de-9a35e7112727" : {
      "Button_1" : [
        "e6b4de06-9473-416c-a777-33c14c84caf5"
      ]
    },
    "d12245cc-1680-458d-89dd-4f0d7fb22724" : {
      "Image_1" : [
        "e6b4de06-9473-416c-a777-33c14c84caf5"
      ]
    },
    "7d81144a-bd8e-4a84-83f1-94a7acfef088" : {
      "Two-line-item_22" : [
        "e6b4de06-9473-416c-a777-33c14c84caf5"
      ],
      "Two-line-item_34" : [
        "3ce1d6ba-3660-41a1-8ed5-d8cfe6aa4186"
      ],
      "Two-line-item_12" : [
        "e5c4986d-5cfc-4172-b800-0daeda45b832"
      ],
      "Two-line-item_23" : [
        "7d81144a-bd8e-4a84-83f1-94a7acfef088"
      ],
      "Two-line-item_28" : [
        "5a16e1a6-7f21-441e-9071-97f456c53522"
      ],
      "Two-line-item_43" : [
        "a2d965d2-311c-4174-9f0f-9777417eb4ca"
      ],
      "Two-line-item_44" : [
        "059e1423-70e2-4ca3-8ff7-9b4555e68623"
      ],
      "Two-line-item_45" : [
        "d897edba-97e4-46fc-ae38-a7850df3bf9f"
      ]
    },
    "059e1423-70e2-4ca3-8ff7-9b4555e68623" : {
      "Two-line-item_22" : [
        "e6b4de06-9473-416c-a777-33c14c84caf5"
      ],
      "Two-line-item_34" : [
        "3ce1d6ba-3660-41a1-8ed5-d8cfe6aa4186"
      ],
      "Two-line-item_12" : [
        "e5c4986d-5cfc-4172-b800-0daeda45b832"
      ],
      "Two-line-item_23" : [
        "7d81144a-bd8e-4a84-83f1-94a7acfef088"
      ],
      "Two-line-item_28" : [
        "5a16e1a6-7f21-441e-9071-97f456c53522"
      ],
      "Two-line-item_43" : [
        "a2d965d2-311c-4174-9f0f-9777417eb4ca"
      ],
      "Two-line-item_44" : [
        "059e1423-70e2-4ca3-8ff7-9b4555e68623"
      ],
      "Two-line-item_45" : [
        "d897edba-97e4-46fc-ae38-a7850df3bf9f"
      ]
    }    
  }

  window.jimLinks = jimLinks;
})(window);